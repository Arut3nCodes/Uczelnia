package Osoba;

import java.util.Objects;

public abstract class PracownikUczelni extends Osoba{
    protected String stanowisko;
    protected int stazPracy;
    protected int pensja;

    public PracownikUczelni(){

    }

    public String getStanowisko() {
        return stanowisko;
    }

    public void setStanowisko(String stanowisko) {
        this.stanowisko = stanowisko;
    }

    public int getStazPracy() {
        return stazPracy;
    }

    public void setStazPracy(int stazPracy) {
        this.stazPracy = stazPracy;
    }

    public int getPensja() {
        return pensja;
    }

    public void setPensja(int pensja) {
        this.pensja = pensja;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PracownikUczelni pracownik = (PracownikUczelni) o;
        return getPesel() == pracownik.getPesel();
    }
}
