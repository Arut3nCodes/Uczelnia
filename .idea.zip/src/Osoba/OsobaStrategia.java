package Osoba;

public interface OsobaStrategia {
    public void getStan();
}
