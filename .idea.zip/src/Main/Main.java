package Main;

import GUI.*;
import Uczelnia.*;

public class Main {
    public static void main(String[] args){
        Uczelnia u = new Uczelnia("Uczelnia");

        App a = new App(u);
    }
}
